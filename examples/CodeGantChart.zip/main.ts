//ideas: https://legendkeeper.com/timeline-maker/
// Wir importieren aus der Obsidian-API die Klassen/Typen, die wir brauchen:
//  - App: um auf Vault und Cache zuzugreifen
//  - Plugin: Basis-Klasse für unser Plugin
//  - MarkdownPostProcessorContext: Kontext für Codeblock-Renderer
//  - TFile: Dateityp für Notizen
import { App, Plugin, MarkdownPostProcessorContext, TFile, Notice, PluginManifest } from "obsidian";
//import {Calendarium} from "Calendarium"

// Wir importieren das gesamte D3-Namespace, um Skalen, Achsen, Zoom usw. zu nutzen.
import * as d3 from "d3";

import {
    GanttPluginSettings,
    DEFAULT_SETTINGS,
    GanttSettingTab,
    FrontmatterMapping
} from "./components/settings";

import {
    getRelevantCalendarFiles,
    RenderItem,
    createRenderItemsFromFrontmatter,
    getCalendariumEvents
} from "./components/dataCollecting";

import {
    renderGanttChartInternal,
    
} from "./components/renderEngine";
import {
    buildCalendarAxisDefinition,
    CalendarAxisDefinition
} from "./components/calendarAxis";

// ----------------------------------------------------------
// 1. Plugin-Klasse: Codeblock-Processor (inline + calendar)
// ----------------------------------------------------------

export default class TTRPG_ZoomTimeline extends Plugin {
    //Property section
    settings: GanttPluginSettings;

//===== Start: ZoomTimeline Funktionen ====================================================================================
    // Plugin Settings Funktion um Settings des Plugins zu laden
    async loadSettings(): Promise<void> {
        const loaded = await this.loadData();                       // loadData liest gespeicherte JSON-Daten
        this.settings = Object.assign({}, DEFAULT_SETTINGS, loaded);// DEFAULTS + geladene Daten mergen
    }

    // Plugin Settings Funktion um Settings des Plugins zu speichern
    async saveSettings(): Promise<void> {
        await this.saveData(this.settings);                         // saveData schreibt JSON in .obsidian/plugins/<id>/data.json
    }

    pluginPresent(pluginName:string = "calendarium"): boolean {
        let yesNo:boolean = false;
        const pluginId = pluginName;

    // Check if installed (exists in registry)
    const plugins = (this.app as any).plugins;
    const isInstalled = plugins.manifests.hasOwnProperty(pluginId) ?? false;
 
    // Check if enabled (loaded and active)
    const isEnabled = plugins.enabledPlugins.has(pluginId) ?? false;

    // Alternative: get plugin instance (only if enabled)
    //const pluginInstance = app.plugins.getPlugin(pluginId);

if (isInstalled) {console.log("Plugin is installed");}

if (isEnabled) {console.log("Plugin is enabled");}

//if (pluginInstance) {
  //  console.log("Plugin instance is loaded:", pluginInstance);
//}
if(isInstalled && isEnabled){yesNo=true}
    return yesNo
    }
//==== End: ZoomTimeline Funktionen =================================================================================================================================
    
//===== Start: On load section ================================================================================================================
    async onload(): Promise<void> {
        console.log("TTRPG Zoom Timeline Plugin is loading");
    

    // 1) Settings laden (oder Defaults, falls keine vorhanden)
        await this.loadSettings();

    // 2) Settings-Tab registrieren
        this.addSettingTab(new GanttSettingTab(this.app, this));
      /*
        const targetId = "some-plugin-id";
        if (!this.manifest[targetId]) {
            console.warn("Required plugin not installed");
            Notice
        return;
        }
        
        console.log("Manifest ",this.manifest);
  if (!this.manifest.name) {
    console.warn("Required plugin is installed but disabled");
    return;
  }

  const other = this.manifest[targetId];
  // safe to interact with `other` here
  */
this.registerMarkdownCodeBlockProcessor(
    "gant-calendarium",
                async (source: string, el: HTMLElement, ctx: MarkdownPostProcessorContext) => {
                
                //Create a test Datapoint
                let testDataItem:RenderItem = {
                    type: "point",
                    group: "Testgroup",
                    name: "TestLabel",
                    start: 5,
                    end: 5,
                    x: 5,
                    noteName:"Test",
                    color:"red",
                    lane:1
                } 

                //Create the Array which will hold all test Data
                let renderData: RenderItem[]=[];
                renderData.push(testDataItem) // push a Test Data Item into the array

                    el.empty(); // create an empty main element

                    // TODO: write a function which will take a string argument, determine if it is a percentile and return a number which corresponds
                    //to the pixel size available in the view according to the percentile (for example if the view allows for 1000 pixel and the percentile is 80% it returns 800)
                    //or which returns the string as number (and checks if the view has enough pixels - otherwise it adjusts?)
                    const width: number = 900;
                    //TODO: write a function which take a line hight in pixel as argument and the height information (as object) and then calculates the minimum height necessary for that and returns that as height
                    // hight information or returns a new line hight
                    const height: number = 520;

                    const calendarContainer = el.createEl("div", { cls: "tzt-calendar-container" }); //Root container
                    const calendarControlsContainer = el.createEl("div", { cls: "tzt-controls-container" }); //Holds Controls to enable or disable groups
                    const calendarChartContainer = el.createEl("div", { cls: "tzt-chart-container" }); //Holds the SVG object which holds and displays the gant chart bars and points
                
                    /*
                    const svgChartEl = d3.select(document.createElementNS("http://www.w3.org/2000/svg", "svg"));
                    svgChartEl
                        .classed("tzt-chart-svg", true)
                        .attr("width", width)
                        .attr("height", height)
                        .append("text")
                        .attr("x", 20)
                        .attr("y", 30)
                        .text("Hello SVG");
                    
                    VS

                    const svgChartEl: SVGSVGElement = document.createElementNS("http://www.w3.org/2000/svg", "svg");

                        svgChartEl.classList.add("tzt-chart-svg");
                        svgChartEl.setAttribute("width", String(width));
                        svgChartEl.setAttribute("height", String(height));

                        const textEl = document.createElementNS("http://www.w3.org/2000/svg", "text");
                        textEl.setAttribute("x", "20");
                        textEl.setAttribute("y", "30");
                        textEl.textContent = "Hello SVG";
                        svgChartEl.appendChild(textEl);

                        calendarChartContainer.appendChild(svgChartEl);
                        */
                    // Create the SVG object on the document and add it to the chart container also define height and width
                    const svgChartEl: SVGSVGElement = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    
                    svgChartEl.classList.add("tzt-chart-svg");
                    svgChartEl.setAttribute("width", String(width));
                    svgChartEl.setAttribute("height", String(height));
                    
                    d3.select(svgChartEl)
                        .append("text")
                        .attr("x", 20)
                        .attr("y", 30)
                        .text("Hello SVG");
                    console.log("d3 element",d3)
                    calendarChartContainer.appendChild(svgChartEl);

                    
            }
);

        this.registerMarkdownCodeBlockProcessor(
            "tz-timeline",
            async (source: string, el: HTMLElement, ctx: MarkdownPostProcessorContext) => {
                el.empty();

                let config: any;
                try {
                    config = JSON.parse(source);
                } catch (e) {
                    el.createEl("pre", {
                        text: "Fehler beim Parsen des JSON im ```gantt Codeblock: " + String(e)
                    });
                    return;
                }

                const width: number = typeof config.width === "number" ? config.width : 900;
                const height: number = typeof config.height === "number" ? config.height : 520;

                const controlsContainer = el.createEl("div", { cls: "tzt-controls-container" });
                const chartContainer = el.createEl("div", { cls: "tzt-chart-container" });

                const svgEl: SVGSVGElement = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                chartContainer.appendChild(svgEl);
                svgEl.classList.add("tzt-chart-svg");
                svgEl.setAttribute("width", String(width));
                svgEl.setAttribute("height", String(height));

                const extractLinkTarget = (noteName: string): string => {
                    if (noteName.startsWith("[[") && noteName.endsWith("]]")) {
                        return noteName.substring(2, noteName.length - 2);
                    }
                    return noteName;
                };

                let allRenderItems: RenderItem[] = [];
                let calendarAxisDefinition: CalendarAxisDefinition | null = null;

                const mode: string = typeof config.mode === "string" ? config.mode : "inline";
                console.log("TZT: Mode of operation is: ",config.mode)
                console.log("TZT: Current config is: ",config)
                if (mode === "inline") {
                    const items: unknown = config.items;
                    if (!Array.isArray(items)) {
                        el.createEl("pre", { text: "gantt (inline): 'items' muss ein Array sein." });
                        return;
                    }

                    allRenderItems = (items as any[]).map(d => {
                        const isRange = d.type === "range";
                        const start = Number(d.start);
                        const end = isRange ? Number(d.end ?? d.start) : start;
                        return {
                            type: isRange ? "bar" : "point",
                            group: d.group ?? "Standard",
                            name: d.content,
                            start,
                            end,
                            x: start,
                            noteName: d.noteName ?? d.content,
                            color: d.color
                        } as RenderItem;
                    });
                } else if (mode === "calendar") {
                    console.log("TZT: I entered the calendar mode and this is the config.MAPPING: ",config.mapping)
                    //checks if the calendarium plugin is installed
                    if (this.pluginPresent()) {
                
                    // @ts-ignore
                    const calendarAPI = Calendarium.getAPI("DSA"); //TODO: Change to getting a variable calendar and also check if calendar could be retrieved
                    console.log("Fully API and methods? ",calendarAPI)
                    const calendariumKalender=calendarAPI.getObject();
                    calendarAxisDefinition = buildCalendarAxisDefinition(calendariumKalender);
                    console.log("TZT Calendarium calendarium Kalender",calendariumKalender)
                    const currentDate = calendarAPI.getCurrentDate()
                    console.log("TZT Calendarium current Date ",currentDate)
                     
                    const stringToDate = calendarAPI.parseDate("1021-Praios-4")
                    console.log("TZT Calendarium stringToDate: ",stringToDate)
                    
                    
                    const calendarEvents= calendarAPI.getEvents()
                    console.log("TZT Calendarium Events: ",calendarEvents)
                    const sortedEvents= calendarAPI.sortEvents(calendarEvents)
                    console.log("TZT Calendarium Events SORTED: ",sortedEvents)

                    const dateObject= calendarAPI.getDate(5,5,1021)
                    console.log("TZT Calendarium dateToString: ",dateObject)

                    const toDisplayDate = calendarAPI.toDisplayDate(dateObject,null,"Y-MMM-DD")
                    console.log("TZT Calendarium toDisplayDate: ",toDisplayDate)

                    const store = calendarAPI.getStore()
                    console.log("Calendar Store: ",store)
                    const storeTest = store.getDaysBeforeDate(dateObject)
                    console.log("Store methods and properties: ",storeTest)

                    console.log("Resulting Render Items: ",getCalendariumEvents("DSA"))
                    if (!config.mapping || !config.relevantCalendarName) {
                        el.createEl("pre", {
                            text: "gantt (calendar): 'mapping' und 'relevantCalendarName' müssen angegeben werden."
                        });
                        return;
                    }
                    } else {
                        new Notice("No Calendarium plugin installed or aktivated. Calendarium events will not be loaded. Data will be inconsistent")
                    }



                    const mapping: FrontmatterMapping = this.settings.mapping;
                    console.log("TZT: Config Mapping exists?: ", config.mapping)
                    const relevantCalendarName: string = config.relevantCalendarName;
                        // CalendarName: entweder aus dem Codeblock (override) oder aus den Default-Settings
    /*const relevantCalendarName: string =
        typeof config.relevantCalendarName === "string" && config.relevantCalendarName.trim().length > 0
            ? config.relevantCalendarName
            : this.settings.defaultCalendarName;*/
                    console.log("TZT: Relevant Calendar Name: ",relevantCalendarName)

                    let scaling: ((raw: any) => number) | undefined = undefined;



                  //  if (config.scaling === "date") {
                  //      scaling = (raw: any) => new Date(raw).getTime();
                  //  }

                                       // Skalierung: Codeblock kann override setzen, sonst Defaults aus Settings
    /*let scaling: ((raw: any) => number) | undefined = undefined;
                        const scalingMode: "none" | "date" =
        config.scaling === "date" || config.scaling === "none"
            ? config.scaling
            : this.settings.defaultScalingMode;*/

            
    let scalingMode =null; // For now scaling needs to be a number!
    if (scalingMode === "date") {
        // Datums-Strings -> ms seit Epoche
        scaling = (raw: any) => new Date(raw).getTime();
    } else {
        // "none": keine spezielle Skalierung, Werte werden direkt in Number konvertiert
        scaling = (raw: any) => Number(raw);
    }

    
                    allRenderItems = await createRenderItemsFromFrontmatter(
                        this.app,
                        mapping,
                        relevantCalendarName,
                        scaling
                    );
                } else {
                    el.createEl("pre", {
                        text: `gantt: Unbekannter mode "${mode}". Erlaubt sind "inline" und "calendar".`
                    });
                    return;
                }

                if (allRenderItems.length === 0) {
                    el.createEl("pre", {
                        text: "gantt: Keine Daten gefunden."
                    });
                    return;
                }

                const activeGroups = new Set<string>(allRenderItems.map(d => d.group));
                const activeTypes = new Set<"bar" | "point">(["bar", "point"]);

                const allGroups = Array.from(activeGroups);
                const groupFilterContainer = controlsContainer.createEl("div", { cls: "tzt-group-filters" });
                groupFilterContainer.createEl("span", { text: "Gruppen: " });
                allGroups.forEach(groupName => {
                    const labelEl = groupFilterContainer.createEl("label", { cls: "tzt-group-filter-label" });
                    const checkbox = labelEl.createEl("input", { type: "checkbox" }) as HTMLInputElement;
                    checkbox.checked = true;
                    labelEl.createSpan({ text: ` ${groupName} ` });
                    checkbox.addEventListener("change", () => {
                        if (checkbox.checked) activeGroups.add(groupName); else activeGroups.delete(groupName);
                        renderFiltered();
                    });
                });

                const typeFilterContainer = controlsContainer.createEl("div", { cls: "tzt-type-filter" });
                typeFilterContainer.createEl("span", { text: "Typ: " });
                const typeSelect = typeFilterContainer.createEl("select") as HTMLSelectElement;
                [
                    { value: "both", label: "Balken & Punkte" },
                    { value: "bars", label: "Nur Balken" },
                    { value: "points", label: "Nur Punkte" }
                ].forEach(o => {
                    const opt = typeSelect.createEl("option") as HTMLOptionElement;
                    opt.value = o.value;
                    opt.text = o.label;
                });
                typeSelect.value = "both";
                typeSelect.addEventListener("change", () => {
                    activeTypes.clear();
                    if (typeSelect.value === "both") {
                        activeTypes.add("bar");
                        activeTypes.add("point");
                    } else if (typeSelect.value === "bars") {
                        activeTypes.add("bar");
                    } else if (typeSelect.value === "points") {
                        activeTypes.add("point");
                    }
                    renderFiltered();
                });

                const getFilteredRenderItems = (): RenderItem[] => {
                    return allRenderItems.filter(d =>
                        activeGroups.has(d.group) &&
                        activeTypes.has(d.type)
                    );
                };

                const renderFiltered = () => {
                    const items = getFilteredRenderItems();
                    renderGanttChartInternal(
                        svgEl,
                        () => items,
                        ctx.sourcePath,
                        extractLinkTarget,
                        calendarAxisDefinition
                    );
                };

                renderFiltered();
            }
        );
    }
//===== End: On load section =============================================================================================================

//===== Start: On unload section ================================================================================================================
    onunload(): void {
        console.log("TTRPG Zoom Timeline is unloading");
    }
//===== End: On unload section =============================================================================================================
}
