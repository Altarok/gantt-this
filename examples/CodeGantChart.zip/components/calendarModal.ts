import { App, Modal, Setting } from "obsidian";
import { MultiColumnListModal } from "./modals";

export class CalendarConfigModal extends Modal {

    private plugin:any

    constructor(app:App,plugin:any){
        super(app)
        this.plugin = plugin
    }

    onOpen(){

        const {contentEl}=this
        contentEl.empty()

        contentEl.createEl("h3",{text:"Calendar Configuration"})

        new Setting(contentEl)
            .setName("Edit Cycles")
            .setDesc("Define year / month / day hierarchy")
            .addButton(btn=>btn
                .setButtonText("Edit")
                .setCta()
                .onClick(()=>this.openCycleEditor())
            )

        new Setting(contentEl)
            .setName("Edit Cycle Instances")
            .setDesc("Define months etc.")
            .addButton(btn=>btn
                .setButtonText("Edit")
                .onClick(()=>this.openInstanceEditor())
            )
    }


private openCycleEditor(){

    const initialRows = this.plugin.settings.calendars[0]?.cycles.map(c=>[
        c.id,
        c.category,
        c.level.toString(),
        c.repeating ? "true":"false"
    ]) ?? []

    const headers = [
        "Cycle ID",
        "Category",
        "Level",
        "Repeating"
    ]

    new MultiColumnListModal(
        this.app,
        ["Cycles","Define the calendar hierarchy"],
        initialRows,
        async (rows)=>{

            if(!rows) return

            const cycles = rows.map(r=>({
                id:r[0],
                category:r[1],
                level:Number(r[2]),
                repeating:r[3]==="true"
            }))

            if(!this.plugin.settings.calendars.length){

                this.plugin.settings.calendars.push({
                    name:"Custom",
                    cycles:[],
                    instances:[]
                })
            }

            this.plugin.settings.calendars[0].cycles = cycles

            await this.plugin.saveSettings()
        },
        headers
    ).open()
}

private openInstanceEditor(){

    const initialRows = this.plugin.settings.calendars[0]?.instances.map(i=>[
        i.id,
        i.cycleId,
        i.name,
        i.index.toString(),
        i.baseLength.toString()
    ]) ?? []

    const headers = [
        "Instance ID",
        "Cycle",
        "Name",
        "Index",
        "Length"
    ]

    new MultiColumnListModal(
        this.app,
        ["Cycle Instances","Define months / seasons / etc."],
        initialRows,
        async (rows)=>{

            if(!rows) return

            const instances = rows.map(r=>({

                id:r[0],

                cycleId:r[1],

                name:r[2],

                index:Number(r[3]),

                baseLength:Number(r[4])
            }))

            if(!this.plugin.settings.calendars.length){

                this.plugin.settings.calendars.push({
                    name:"Custom",
                    cycles:[],
                    instances:[]
                })
            }

            this.plugin.settings.calendars[0].instances = instances

            await this.plugin.saveSettings()
        },
        headers
    ).open()
}}