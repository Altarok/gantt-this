import { App, Plugin, MarkdownPostProcessorContext, TFile, Notice, PluginManifest } from "obsidian";

import {
    FrontmatterMapping
} from "./settings";

export interface RenderItem {
    type: "bar" | "point";   // 'bar' = Balken, 'point' = Punkt
    group: string;           // Gruppenname (Y-Achse)
    name: string;            // Label-Text, der angezeigt wird
    start: number;           // Startwert auf der X-Achse (für Balken)
    end: number;             // Endwert auf der X-Achse (für Balken; bei Punkt = start)
    x: number;               // X-Wert für Punkte (zusätzlich für Einheitlichkeit)
    noteName?: string;        // Pfad oder Wikilink-Ziel für Obsidian-Link
    color?: string;          // Farbe des Balkens/Punktes
    lane?: number;           // Lane-Index innerhalb einer Gruppe (wird im Layout berechnet)
}

/**
 * getRelevantCalendarFiles:
 *  - holt alle Markdown-Dateien im Vault,
 *  - liest deren Frontmatter aus dem Obsidian-Metadaten-Cache,
 *  - prüft, ob das Feld mapping.calendarName den relevantCalendarName enthält,
 *  - gibt nur diejenigen TFile zurück, deren Kalendernamen passen.
 * @param app das App Objekt von Obsidian
 * @param mapping definiert die Property Strings/Namen die der Kalender nutzen soll
    *  calendarName: string; Frontmatter Kalender Name
        group: string; Frontmatter Gruppename
        start: string; Frontmatter Startzeitpunkt Name
        end: string; Frontmatter Endzeitpunkt Name
        color: string;  Frontmatter Farb Name
 * @param relevantCalendarName der relevante Name des Kalenders für den Kalendertermine gesucht werden sollen
 */

        //holt alle Dateien deren Kalendereinträge relevant sind
export function getRelevantCalendarFiles(
    app: App,                          // Obsidian-App, um Vault & Cache zu nutzen
    mapping: FrontmatterMapping,       // Mapping der Frontmatter-Feldnamen
    relevantCalendarName: string       // gesuchter Kalendername
): TFile[] {
    const relevantFiles: TFile[] = [];           // Ergebnisliste initialisieren für die Rückgabe der relevanten files
    const files = app.vault.getMarkdownFiles();  // alle Markdown-Dateien im Vault holen
    

    for (const file of files) {                  // über alle Dateien iterieren
        const cache = app.metadataCache.getFileCache(file); // Holt für ein TFile Object die entsprechende Datei/Notiz
        if (!cache || !cache.frontmatter) continue;         // falls keine Datei vorhanden oder kein Frontmatter, dann weiterloopen

        const fm = cache.frontmatter as Record<string, any>; // Frontmatter als generisches record Objekt

        const calendarVal = fm[mapping.calendarName];        // Kalenderfeld aus Frontmatter auslesen
        if (calendarVal == null) continue;                   // wenn kein Kalenderfeld, Datei ignorieren

        let isRelevant = false;                              // Flag, ob Datei relevant ist

        if (Array.isArray(calendarVal)) {                    // Fall: Kalenderfeld ist ein Array
            isRelevant = calendarVal.includes(relevantCalendarName); // prüfe, ob gesuchter Kalendername enthalten ist
        } else {                                             // Fall: Kalenderfeld ist ein skalarer Wert
            isRelevant = String(calendarVal) === relevantCalendarName; // String-Vergleich auf Gleichheit
        }

        if (isRelevant) {                                    // wenn relevant
            relevantFiles.push(file);                        // Datei in Ergebnisliste aufnehmen
        }
    }

    return relevantFiles;                                    // Liste der relevanten Dateien zurückgeben
}

// ----------------------------------------------------------
// 2. RenderItems aus Frontmatter erzeugen (Calendar-Modus)
// ----------------------------------------------------------

/**
 * collectRenderItemsFromFrontmatter:
 *  - nutzt getRelevantCalendarFiles, um passende Notizen zu finden,
 *  - liest aus deren Frontmatter Start, End, Group, Color,
 *  - erzeugt RenderItems für den Gantt-Renderer.
 */
export async function createRenderItemsFromFrontmatter(
    app: App,                               // Obsidian-App-Instanz
    mapping: FrontmatterMapping,            // Mapping der Frontmatter-Feldnamen
    relevantCalendarName: string,           // relevanter Kalendername
    scaling?: (raw: any) => number          // optionale Skalierungsfunktion für Start/End (z.B. Datums-String -> Zahl)
): Promise<RenderItem[]> {
    const results: RenderItem[] = [];       // Ergebnisliste initialisieren

    const relevantFiles: TFile[] = getRelevantCalendarFiles(app, mapping, relevantCalendarName); // relevante Dateien holen

    for (const file of relevantFiles) {     // über relevante Dateien iterieren
        const cache = app.metadataCache.getFileCache(file); // Cache holen
        if (!cache || !cache.frontmatter) continue;         // ohne Frontmatter uninteressant

        const fm = cache.frontmatter as Record<string, any>; // Frontmatter-Objekt

        // Start-Feld ist Pflicht
        const rawStart = fm[mapping.start];                 // Rohwert des Start-Feldes
        if (rawStart == null) {                             // wenn kein Start
            console.log(
                `Gantt: Note "${file.path}" hat kein Start-Feld "${mapping.start}" in der Frontmatter.`
            );
            continue;                                       // Datensatz verwerfen
        }

        const startNum: number = scaling ? scaling(rawStart) : Number(rawStart); // Start in Zahl umwandeln
        if (Number.isNaN(startNum)) {                       // wenn keine gültige Zahl
            console.log(
                `Gantt: Start-Wert in Note "${file.path}" (Feld "${mapping.start}") konnte nicht in eine Zahl umgewandelt werden.`
            );
            continue;                                       // Datensatz verwerfen
        }

        // End-Feld ist optional
        let endNum = startNum;                              // Default: kein End-Wert -> Punkt
        let isBar = false;                                  // Flag, ob es ein Balken ist

        if (mapping.end) {                                  // nur wenn ein End-Feld im Mapping angegeben ist
            const rawEnd = fm[mapping.end];                 // End-Rohwert aus Frontmatter
            if (rawEnd != null) {                           // wenn vorhanden
                const endCandidate: number = scaling ? scaling(rawEnd) : Number(rawEnd); // End in Zahl umwandeln
                if (!Number.isNaN(endCandidate)) {          // nur bei gültiger Zahl übernehmen
                    endNum = endCandidate;                  // End-Wert setzen
                    if (endNum !== startNum) isBar = true;  // wenn Start != End, dann Balken
                }
            }
        }

        const type: "bar" | "point" = isBar ? "bar" : "point"; // Typ aus Flag ableiten

        // Gruppenfeld ist optional
        let groupName = "Standard";                         // Default-Gruppe
        if (mapping.group) {                                // nur wenn im Mapping definiert
            const rawGroup = fm[mapping.group];             // Rohwert der Gruppe
            if (rawGroup != null) {                         // wenn vorhanden
                const newGroup = String(rawGroup).trim();          // zu String konvertieren und trimmen
                if (newGroup.length > 0) groupName = newGroup;            // nur bei nicht-leer Gruppe setzen
            }
        }

        // Farbe ist optional
        let color = "#ffff00";                              // Default-Farbe: Gelb
        if (mapping.color) {                                // nur wenn im Mapping definiert
            const rawColor = fm[mapping.color];             // Rohwert der Farbe
            if (rawColor != null) color = String(rawColor); // Farbe aus Frontmatter übernehmen
        }

        // Label und Notiz-Link
        const labelName = file.basename;                    // Dateiname ohne .md als Label
        const notePath = file.path;                         // Pfad der Notiz als noteName

        // RenderItem erstellen und zur Ergebnisliste hinzufügen
        const item: RenderItem = {
            type,
            group: groupName,
            name: labelName,
            start: startNum,
            end: endNum,
            x: startNum,
            noteName: notePath,
            color
        };

        results.push(item);                                 // RenderItem speichern
    }

    // Alle gesammelten RenderItems zurückgeben
    return results;
}

/*
fc-calendar	Calendar name or array of calendar names to the event should be added to.
fc-date	Date string, date object or array of date objects with year, month and day parameters.
fc-category	Name of the event category you want the event assigned to.
fc-display-name	An optional display name for the event. Otherwise, the file name is used.
fc-end	Date string, date object or array of date objects with year, month and day parameters.
*/
export function getCalendariumEvents(relevantCalendarName: string): RenderItem[] {
    const results: RenderItem[] = []; 
    //let item: RenderItem={};      // Ergebnisliste initialisieren

    console.log("TZT: Entered Calendarium event collection")
                    //checks if the calendarium plugin is installed
                    if (pluginPresent()) {
                
                    // @ts-ignore
                    const calendarAPI = Calendarium.getAPI(relevantCalendarName); 
                    console.log("Fully API and methods? ",calendarAPI)
                    
                    const calendarStore = calendarAPI.getStore() // console.log("Calendar Store: ",calendarStore)  
                    const calendarEvents= calendarAPI.getEvents() // console.log("TZT Calendarium Events: ",calendarEvents)
                    const sortedEvents:any[]= calendarAPI.sortEvents(calendarEvents) 
                    console.log("TZT Calendarium Events SORTED for processing: ",sortedEvents)
                    console.log("TZT Event Array lenght ",sortedEvents.length)
if (calendarEvents.length>=1){
for (const calendarEvent of calendarEvents ){
/*
{
    type: "bar" | "point";   // 'bar' = Balken, 'point' = Punkt
    group: string;           // Gruppenname (Y-Achse)
    name: string;            // Label-Text, der angezeigt wird
    start: number;           // Startwert auf der X-Achse (für Balken)
    end: number;             // Endwert auf der X-Achse (für Balken; bei Punkt = start)
    x: number;               // X-Wert für Punkte (zusätzlich für Einheitlichkeit)
    noteName: string;        // Pfad oder Wikilink-Ziel für Obsidian-Link
    color?: string;          // Farbe des Balkens/Punktes
    lane?: number;          // Gant Zeile in der das Datum im SVG angezeigt wird
}
    */
console.log("Processing Event: ",calendarEvent)

        let item: RenderItem = {
            type: "point",
            group: calendarEvent?.category ?? "standard",
            name: calendarEvent?.name ?? calendarEvent?.note ?? "",
            start: 0,
            end: 0,
            x: 0,
            noteName: calendarEvent?.note,
            color: "red"
        };

        if (calendarEvent.type==="Range") {
            item.type ="bar"
            const dateForDays = calendarEvent?.end ?? {year:0,month:0,day:0}
            const numberOfDays = calendarStore.getDaysBeforeDate(dateForDays)+1
            item.end = numberOfDays
        }

        if (calendarEvent?.date){
            const dateForDays = calendarEvent?.date ?? {year:0,month:0,day:0}
            const numberOfDays = calendarStore.getDaysBeforeDate(dateForDays)+1
            item.start = numberOfDays
            item.x = numberOfDays
        }

        results.push(item)

}
}
/*
                    const calendariumKalender=calendarAPI.getObject();
                    console.log("TZT Calendarium calendarium Kalender",calendariumKalender)
                    const currentDate = calendarAPI.getCurrentDate()
                    console.log("TZT Calendarium current Date ",currentDate)
                     
                    const stringToDate = calendarAPI.parseDate("1021-Praios-4")
                    console.log("TZT Calendarium stringToDate: ",stringToDate)
                    
                    


                    const dateObject= calendarAPI.getDate(5,5,1021)
                    console.log("TZT Calendarium dateToString: ",dateObject)

                    const toDisplayDate = calendarAPI.toDisplayDate(dateObject,null,"Y-MMM-DD")
                    console.log("TZT Calendarium toDisplayDate: ",toDisplayDate)

                    const store = calendarAPI.getStore()
                    console.log("Calendar Store: ",store)
                    const storeTest = store.getDaysBeforeDate(dateObject)
                    console.log("Store methods and properties: ",storeTest)*/


}
    return results;
}

 function pluginPresent(pluginName:string = "calendarium"): boolean {
        let yesNo:boolean = false;
        const pluginId = pluginName;

    // Check if installed (exists in registry)
    const plugins = (this.app as any).plugins;
    const isInstalled = plugins.manifests.hasOwnProperty(pluginId) ?? false;
 
    // Check if enabled (loaded and active)
    const isEnabled = plugins.enabledPlugins.has(pluginId) ?? false;

    // Alternative: get plugin instance (only if enabled)
    //const pluginInstance = app.plugins.getPlugin(pluginId);

if (isInstalled) {console.log("Plugin is installed");}

if (isEnabled) {console.log("Plugin is enabled");}

//if (pluginInstance) {
  //  console.log("Plugin instance is loaded:", pluginInstance);
//}
if(isInstalled && isEnabled){yesNo=true}
    return yesNo
    }