import { App, Modal, Setting,ButtonComponent  } from "obsidian";
//import {  } from "./settings";


export type RowData = string[];
export type RowArray = RowData[];

export class MultiColumnListModal extends Modal {
  // =========================
  // Internal state
  // =========================

  private rows: RowArray;
  private columnCount: number;
  private columnHeaders: string[];
  private onSubmit: (result: RowArray | null) => void;
  private rowsContainer: HTMLElement | null = null;
  private heading: string;
  private headingText: string;

  // ----- Stable event handlers -----
  private resizeHandler = this.sizeModalToGrid.bind(this);
  private handleSubmit = this._handleSubmit.bind(this);
  private handleCancel = this._handleCancel.bind(this);
  private handleAddRowGlobal = this._addRow.bind(this);

  constructor(
    app: App,
    heading: string[] = ["", ""],
    initialRows: RowArray = [],
    onSubmit: (result: RowArray | null) => void,
    columnHeaders: string[] = []
  ) {
    super(app);

    this.heading = heading[0];
    this.headingText = heading[1];

    this.columnCount =
      columnHeaders.length || (initialRows[0]?.length ?? 2);

    this.columnHeaders =
      columnHeaders.length === this.columnCount
        ? columnHeaders
        : Array(this.columnCount)
            .fill(null)
            .map((_, i) => `Column ${i + 1}`);

    this.rows = initialRows.length
      ? initialRows.map(r => [
          ...r.slice(0, this.columnCount),
          ...Array(
            Math.max(0, this.columnCount - r.length)
          ).fill("")
        ])
      : [Array(this.columnCount).fill("")];

    this.onSubmit = onSubmit;
  }

  // =========================
  // Modal lifecycle
  // =========================

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    this.modalEl.addClass("tzt-settings-modal");

    const inputBoxSize = 25;
    const grid = [
      "12px",
      ...Array(this.columnCount).fill(`${inputBoxSize}rem`),
      "auto"
    ].join(" ");

    this.containerEl.style.setProperty("--tzt-settings-modal-grid-columns", grid);
    contentEl.addClass("tzt-settings-modal-container");

    contentEl.createEl("h3", { text: this.heading });
    contentEl.createDiv({
      cls: "tzt-settings-modal-explanation",
      text: this.headingText
    });

    this.rowsContainer = contentEl.createDiv({
      cls: "tzt-settings-modal-two-column-rows-container"
    });

    this.renderRows();
    queueMicrotask(() => this.sizeModalToGrid());

    // ----- Attach stable resize handler -----
    window.addEventListener("resize", this.resizeHandler);

    // Footer buttons
    const footer = contentEl.createDiv({ cls: "tzt-settings-modal-footer" });

    new Setting(footer)
      .addButton(btn => btn.setButtonText("OK").setCta().onClick(this.handleSubmit))
      .addButton(btn => btn.setButtonText("Cancel").onClick(this.handleCancel));
  }

  onClose() {
    window.removeEventListener("resize", this.resizeHandler);
    this.contentEl.empty();
  }

  // =========================
  // Footer handlers
  // =========================

  private _handleSubmit() {
    const cleaned = this.rows.filter(r => r.some(cell => cell !== ""));
    this.onSubmit(cleaned);
    this.close();
  }

  private _handleCancel() {
    this.onSubmit(null);
    this.close();
  }

  // =========================
  // Dynamic sizing
  // =========================

  private sizeModalToGrid() {
    if (!this.rowsContainer) return;
    const row = this.rowsContainer.querySelector<HTMLElement>(".tzt-settings-modal-column-row");
    if (!row) return;

    const rowWidth = row.getBoundingClientRect().width;
    const styles = getComputedStyle(this.modalEl);

    const padding = parseFloat(styles.paddingLeft) + parseFloat(styles.paddingRight);
    const border = parseFloat(styles.borderLeftWidth) + parseFloat(styles.borderRightWidth);

    this.modalEl.style.width = Math.min(rowWidth + padding + border, window.innerWidth * 0.8) + "px";
  }

  // =========================
  // Row operations (stable references)
  // =========================

  private _addRow() {
    this.rows.push(Array(this.columnCount).fill(""));
    this.renderRows();
  }

  private _deleteRow(index: number) {
    this.rows.length === 1 ? (this.rows[0] = Array(this.columnCount).fill("")) : this.rows.splice(index, 1);
    this.renderRows();
  }

  private _moveRow(index: number, offset: number) {
    const newIndex = index + offset;
    if (newIndex < 0 || newIndex >= this.rows.length) return;
    const [item] = this.rows.splice(index, 1);
    this.rows.splice(newIndex, 0, item);
    this.renderRows();
  }

  private _insertRowAfter(index: number) {
    this.rows.splice(index + 1, 0, Array(this.columnCount).fill(""));
    this.renderRows();
  }

  // =========================
  // Rendering rows
  // =========================

  private renderRows() {
    if (!this.rowsContainer) return;
    this.rowsContainer.empty();

    // Header
    const headerRow = this.rowsContainer.createDiv({ cls: "tzt-settings-modal-column-row tzt-settings-modal-header-row" });
    headerRow.createSpan({ cls: "tzt-settings-modal-row-drag-handle" });

    this.columnHeaders.forEach((header, colIndex) => {
      headerRow.createSpan({ cls: `tzt-settings-modal-column-header tzt-settings-modal-column-${colIndex}`, text: header });
    });

    headerRow.createDiv({ cls: "tzt-settings-modal-bar-buttons tzt-settings-modal-bar-header" });

    // Data rows
    this.rows.forEach((row, index) => {
      const rowEl = this.rowsContainer!.createDiv({ cls: "tzt-settings-modal-column-row", attr: { "data-index": index.toString(), draggable: "true" } });
      const handle = rowEl.createSpan({ cls: "tzt-settings-modal-row-drag-handle", text: "\u22EE\u22EE" });

      for (let col = 0; col < this.columnCount; col++) {
        const input = rowEl.createEl("input", { type: "text", cls: `tzt-settings-modal-column-input tzt-settings-modal-column-${col}` });
        input.value = row[col] ?? "";

        // Reusable input handler
        input.addEventListener("input", this._handleInput);
        input.dataset.rowIndex = index.toString();
        input.dataset.colIndex = col.toString();

        input.addEventListener("keydown", this._handleEnter);
      }

      // Button bar
      const btnBar = rowEl.createDiv({ cls: "tzt-settings-modal-bar-buttons" });

      new Setting(btnBar)
        .addButton(btn => btn.setIcon("circle-arrow-up").onClick(() => this._moveRow(index, -1)))
        .addButton(btn => btn.setIcon("circle-arrow-down").onClick(() => this._moveRow(index, 1)))
        .addButton(btn => btn.setIcon("trash-2").onClick(() => this._deleteRow(index)))
        .addButton(btn => btn.setIcon("plus-circle").onClick(() => this._insertRowAfter(index)));

      this._attachDragHandlers(rowEl, handle);
    });

    // Global Add Row button
    this.rowsContainer.createEl("button", { text: "Add Row", cls: "tzt-settings-modal-add-row-global" })
      .addEventListener("click", this.handleAddRowGlobal);

    queueMicrotask(() => this.sizeModalToGrid());
  }

  // =========================
  // Input handlers (reusable)
  // =========================

  private _handleInput = (e: Event) => {
    const input = e.target as HTMLInputElement;
    const row = Number(input.dataset.rowIndex);
    const col = Number(input.dataset.colIndex);
    if (!isNaN(row) && !isNaN(col)) this.rows[row][col] = input.value;
  };

  private _handleEnter = (e: KeyboardEvent) => {
    const input = e.target as HTMLInputElement;
    const row = Number(input.dataset.rowIndex);
    if (e.key === "Enter" && row === this.rows.length - 1) {
      e.preventDefault();
      this._addRow();
    }
  };

  // =========================
  // Drag & drop (single stable handler)
  // =========================

  private _attachDragHandlers(rowEl: HTMLElement, handle: HTMLElement) {
    let dragStartIndex: number | null = null;

    handle.addEventListener("mousedown", () => (rowEl.draggable = true));
    handle.addEventListener("mouseup", () => (rowEl.draggable = false));

    rowEl.addEventListener("dragstart", (e) => {
      dragStartIndex = Number(rowEl.getAttr("data-index"));
      rowEl.addClass("dragging");
      e.dataTransfer?.setData("text/plain", dragStartIndex.toString());
      e.dataTransfer!.effectAllowed = "move";
    });

    rowEl.addEventListener("dragend", () => {
      rowEl.removeClass("dragging");
      dragStartIndex = null;
    });

    rowEl.addEventListener("dragover", (e) => {
      e.preventDefault();
      rowEl.addClass("drag-over");
    });

    rowEl.addEventListener("dragleave", () => rowEl.removeClass("drag-over"));

    rowEl.addEventListener("drop", (e) => {
      e.preventDefault();
      rowEl.removeClass("drag-over");

      const fromIndex = dragStartIndex ?? Number(e.dataTransfer?.getData("text/plain"));
      const toIndex = Number(rowEl.getAttr("data-index"));

      if (isNaN(fromIndex) || isNaN(toIndex) || fromIndex === toIndex) return;

      const [moved] = this.rows.splice(fromIndex, 1);
      this.rows.splice(toIndex, 0, moved);
      this.renderRows();
    });
  }
}

export class ConfirmModal extends Modal {
  private result: Promise<string> | null = null;
  private resolver: ((result: string) => void) | null = null;

  constructor(
    app: App,
    private text: string,   // erklärender Text des Dialogs
  ) {
    super(app);
  }

  // öffnet das Modal und gibt ein Promise<string> zurück
  openAsPromise(): Promise<string> {
    if (this.result) {
      return this.result; // bereits geöffnet? dann das bestehende Promise zurückgeben
    }

    this.result = new Promise<string>((resolve) => {
      this.resolver = resolve;
    });

    this.open();
    return this.result;
  }

  onOpen() {
    const { contentEl } = this;

    // Titel
    contentEl.createEl("h3", { text: "Confirmation!" });
    
    //contentEl.style.width="fit-content"
   
    
    // Text
    const MessageText = contentEl.createDiv();
    MessageText.innerHTML = this.text
    MessageText.style.setProperty("padding","1.5rem")
    
    // Zeile für Yes / No
    const row1 = contentEl.createDiv({ cls: "tzt-settings-modal-button-row" });
    row1.style.display = "flex";
    //row1.style.alignSelf ="center"
    row1.style.justifyContent = "flex-end";
    row1.style.gap = "10px";
    row1.style.margin = "1rem"
    row1.style.grid
    new ButtonComponent(row1)
      .setButtonText("Yes")
      .setCta()
      .onClick(() => {
        this.resolver?.("yes");
        this.close();
      });
    new ButtonComponent(row1)
      .setButtonText("No")
      .onClick(() => {
        this.resolver?.("no");
        this.close();
      });

    // Cancel unten rechts; inkl. „X“
    const row2 = contentEl.createDiv({ cls: "tzt-settings-modal-button-row" });
    row2.style.display = "flex";
    row2.style.justifyContent = "flex-start";
    new ButtonComponent(row2)
      .setButtonText("Cancel")
      .onClick(() => {
        this.resolver?.("cancel");
        this.close();
      });
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();

    // Schließen per X gilt ebenfalls als Cancel
    if (this.resolver && this.result) {
      this.resolver("cancel");
    }

    this.resolver = null;
    this.result= null;
  }
}



