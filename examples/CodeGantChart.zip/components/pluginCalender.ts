interface Cycle {
    cycleID: string; //a unuique ID - could be an UUID
    cycleLevel:number; //The level where this cycle is belonging to. Like year, month, day then this would be level 2 for month and 3 for year
    longName: string; // name for longToken like "March"
    shortName: string; // name for shortToken like "Mar" for February
    categoryName: string; // general name of the cycle like "Month" or "Year"
    categoryIndex: number; // index number defining the sequence of the category cycles like 3 for February
    baseUnitName: string; //the name of the base unit cycle which defines the base like "day" which  
    length: number; // lenght in terms of base units like 31 for March with a base unit of day which has a lenght of 1 
    totalLenght:number; //the lenght of the cycle as lenghtMultiplier*
    tokenPlace: number;//place of the token in the date string which can be parsed 1 for the most left string part
    longToken:string; //long token definition like MMMM
    shortToken:string; //short token definition like MMM
    numberToken:string; //like MM and then the categoryIndex if it is a repeating cycle. Else a continuing number
    repeating: boolean; //if  this cycle belongs to a repeating cycle
    parentCycle:string; // name of the parent this cycle defines
    leapRules: string; // a set of rules which will return true or false
    leapAddition:number; //if the leapRules are true then this number will be added to this cycles length
    intercalendary:boolean; //if this is an incelendary date
    baseUnit: boolean; // Yes if all units are defined by this one else false. Also then the totalLength is used as base unit
}

interface CalendarDefinition {
    id: string;
    name: string;

    baseUnit: string; // "day"

    cycles: CycleDefinition[];

    epoch?: number;

    format?: DateFormat;
}

interface CycleDefinition {
    id: string;

    categoryName: string;   // "month", "year"
    level: number;

    parentCycle?: string;

    baseUnit: string;

    repeating: boolean;

    instances?: CycleInstance[];
}

interface CycleInstance {
    id: string;

    cycleId: string;

    longName: string;
    shortName: string;

    index: number;

    baseLength: number;

    variableLength: boolean;

    intercalendary?: boolean;

    ruleset?: RuleSet;

    tokens?: TokenDefinition[];
}

interface RuleSet {
    rules: CalendarRule[];
}

interface CalendarRule {
    id: string;

    targetInstance: string;

    condition: RuleCondition;

    adjustment: RuleAdjustment;
}

type RuleCondition =
    | { type: "yearDivisibleBy"; value: number }
    | { type: "yearModulo"; mod: number; equals: number }
    | { type: "cycleValue"; cycle: string; equals: number }
    | { type: "expression"; expr: string };

    type RuleAdjustment =
    | { type: "addLength"; value: number }
    | { type: "setLength"; value: number }
    | { type: "skipInstance" }
    
interface DateFormat {
    format: string; // "DD MMMM YYYY"
    tokens: TokenDefinition[];
}

interface TokenDefinition {
    token: string;       // MMM
    cycle: string;       // month
    type: "long" | "short" | "number";
}


interface LeapRule {
    id: string;

    targetCycle: string; // month, year etc.

    condition: LeapCondition;

    addLength: number;
}

type LeapCondition =
    | { type: "divisibleBy"; value: number }
    | { type: "notDivisibleBy"; value: number }
    | { type: "modEquals"; mod: number; equals: number }
    | { type: "expression"; expr: string };

interface FantasyDate {
    absolute: number; // days since epoch
}