import * as d3 from "d3";

export type CalendarAxisLevel = "day" | "month" | "year" | "era";

export interface CalendarAxisMonth {
    index: number;
    name: string;
    shortName: string;
    length: number;
}

export interface CalendarAxisEra {
    name: string;
    startAbsolute: number;
    endAbsolute: number;
}

export interface CalendarAxisDefinition {
    name: string;
    weekdays: string[];
    months: CalendarAxisMonth[];
    yearLength: number;
    firstWeekDay: number;
    eras: CalendarAxisEra[];
}

export interface CalendarAxisSegment {
    key: string;
    start: number;
    end: number;
    label: string;
    shortLabel?: string;
    tinyLabel?: string;
}

interface RawCalendarDate {
    year?: number;
    month?: number;
    day?: number;
}

interface CalendarAxisDate {
    year: number;
    month: number;
    day: number;
    weekdayIndex: number;
}

export function buildCalendarAxisDefinition(rawCalendar: any): CalendarAxisDefinition | null {
    const staticPart = rawCalendar?.static;
    const rawMonths = Array.isArray(staticPart?.months) ? staticPart.months : [];
    const rawWeekdays = Array.isArray(staticPart?.weekdays) ? staticPart.weekdays : [];

    if (rawMonths.length === 0 || rawWeekdays.length === 0) return null;

    const months: CalendarAxisMonth[] = rawMonths.map((month: any, index: number) => {
        const name = String(month?.name ?? `Month ${index + 1}`);
        const length = Number(month?.length);
        return {
            index,
            name,
            shortName: abbreviate(name, 3),
            length: Number.isFinite(length) && length > 0 ? length : 1
        };
    });

    const weekdays = rawWeekdays.map((weekday: any, index: number) =>
        String(weekday?.name ?? `Day ${index + 1}`)
    );

    const yearLength = d3.sum(months, month => month.length);
    if (yearLength <= 0) return null;

    const definition: CalendarAxisDefinition = {
        name: String(rawCalendar?.name ?? "Calendar"),
        weekdays,
        months,
        yearLength,
        firstWeekDay: Number.isFinite(staticPart?.firstWeekDay) ? Number(staticPart.firstWeekDay) : 0,
        eras: []
    };

    const rawEras = Array.isArray(staticPart?.eras) ? staticPart.eras : [];
    definition.eras = rawEras
        .map((era: any, index: number) => {
            const startAbsolute = dateToAbsolute(definition, era?.date);
            if (!Number.isFinite(startAbsolute)) return null;

            let endAbsolute = Number.POSITIVE_INFINITY;
            if (era?.end) {
                endAbsolute = dateToAbsolute(definition, era.end) - 0.5;
            }

            return {
                name: String(era?.name ?? `Era ${index + 1}`),
                startAbsolute,
                endAbsolute
            } as CalendarAxisEra;
        })
        .filter((era: CalendarAxisEra | null): era is CalendarAxisEra => era !== null)
        .sort((a, b) => a.startAbsolute - b.startAbsolute);

    for (let i = 0; i < definition.eras.length - 1; i++) {
        const current = definition.eras[i];
        const next = definition.eras[i + 1];
        if (!Number.isFinite(current.endAbsolute)) {
            current.endAbsolute = next.startAbsolute - 1;
        }
    }

    return definition;
}

export function choosePrimaryCalendarAxisLevel(
    definition: CalendarAxisDefinition,
    xScale: d3.ScaleLinear<number, number>
): CalendarAxisLevel {
    const pxPerDay = Math.abs(xScale(1) - xScale(0));
    if (pxPerDay >= 24) return "day";

    const avgMonthLength = definition.yearLength / definition.months.length;
    if (pxPerDay * avgMonthLength >= 56) return "month";

    if (pxPerDay * definition.yearLength >= 64) return "year";

    return definition.eras.length > 0 ? "era" : "year";
}

export function getNextCalendarAxisLevel(level: CalendarAxisLevel): CalendarAxisLevel | null {
    if (level === "day") return "month";
    if (level === "month") return "year";
    if (level === "year") return "era";
    return null;
}

export function getCalendarAxisSegments(
    definition: CalendarAxisDefinition,
    level: CalendarAxisLevel,
    domain: [number, number]
): CalendarAxisSegment[] {
    if (level === "day") return getDaySegments(definition, domain);
    if (level === "month") return getMonthSegments(definition, domain);
    if (level === "year") return getYearSegments(definition, domain);
    return getEraSegments(definition, domain);
}

function getDaySegments(
    definition: CalendarAxisDefinition,
    domain: [number, number]
): CalendarAxisSegment[] {
    const startDay = Math.max(1, Math.floor(domain[0]));
    const endDay = Math.max(startDay, Math.ceil(domain[1]));
    const segments: CalendarAxisSegment[] = [];

    for (let absolute = startDay; absolute <= endDay; absolute++) {
        const date = absoluteToCalendarDate(definition, absolute);
        const weekday = definition.weekdays[date.weekdayIndex] ?? "";
        const paddedDay = String(date.day).padStart(2, "0");
        segments.push({
            key: `day-${absolute}`,
            start: absolute - 0.5,
            end: absolute + 0.5,
            label: `${weekday} ${paddedDay}`,
            shortLabel: `${abbreviate(weekday, 3)} ${paddedDay}`,
            tinyLabel: paddedDay
        });
    }

    return filterVisibleSegments(segments, domain);
}

function getMonthSegments(
    definition: CalendarAxisDefinition,
    domain: [number, number]
): CalendarAxisSegment[] {
    const startDate = absoluteToCalendarDate(definition, Math.max(1, domain[0]));
    const endDate = absoluteToCalendarDate(definition, Math.max(1, domain[1]));
    const segments: CalendarAxisSegment[] = [];

    for (let year = startDate.year; year <= endDate.year; year++) {
        let monthStart = firstAbsoluteOfYear(definition, year);
        for (const month of definition.months) {
            segments.push({
                key: `month-${year}-${month.index}`,
                start: monthStart - 0.5,
                end: monthStart + month.length - 0.5,
                label: month.name,
                shortLabel: month.shortName,
                tinyLabel: abbreviate(month.shortName, 1)
            });
            monthStart += month.length;
        }
    }

    return filterVisibleSegments(segments, domain);
}

function getYearSegments(
    definition: CalendarAxisDefinition,
    domain: [number, number]
): CalendarAxisSegment[] {
    const startDate = absoluteToCalendarDate(definition, Math.max(1, domain[0]));
    const endDate = absoluteToCalendarDate(definition, Math.max(1, domain[1]));
    const segments: CalendarAxisSegment[] = [];

    for (let year = startDate.year; year <= endDate.year; year++) {
        const startAbsolute = firstAbsoluteOfYear(definition, year);
        segments.push({
            key: `year-${year}`,
            start: startAbsolute - 0.5,
            end: startAbsolute + definition.yearLength - 0.5,
            label: String(year)
        });
    }

    return filterVisibleSegments(segments, domain);
}

function getEraSegments(
    definition: CalendarAxisDefinition,
    domain: [number, number]
): CalendarAxisSegment[] {
    const segments = definition.eras.map(era => ({
        key: `era-${era.name}-${era.startAbsolute}`,
        start: era.startAbsolute - 0.5,
        end: Number.isFinite(era.endAbsolute) ? era.endAbsolute + 0.5 : Number.POSITIVE_INFINITY,
        label: era.name,
        shortLabel: abbreviate(era.name, 6)
    }));

    return filterVisibleSegments(segments, domain);
}

function absoluteToCalendarDate(
    definition: CalendarAxisDefinition,
    absolute: number
): CalendarAxisDate {
    const abs = Math.max(1, Math.floor(absolute));
    const zeroBased = abs - 1;
    const year = Math.floor(zeroBased / definition.yearLength) + 1;
    let dayOfYear = zeroBased % definition.yearLength;

    let month = 0;
    while (month < definition.months.length - 1 && dayOfYear >= definition.months[month].length) {
        dayOfYear -= definition.months[month].length;
        month += 1;
    }

    return {
        year,
        month,
        day: dayOfYear + 1,
        weekdayIndex: mod(definition.firstWeekDay + zeroBased, definition.weekdays.length)
    };
}

function filterVisibleSegments(
    segments: CalendarAxisSegment[],
    domain: [number, number]
): CalendarAxisSegment[] {
    const [d0, d1] = domain[0] <= domain[1] ? domain : [domain[1], domain[0]];
    return segments.filter(segment => segment.end > d0 && segment.start < d1);
}

function firstAbsoluteOfYear(definition: CalendarAxisDefinition, year: number): number {
    return (year - 1) * definition.yearLength + 1;
}

function dateToAbsolute(definition: CalendarAxisDefinition, rawDate: RawCalendarDate | null | undefined): number {
    if (!rawDate) return Number.NaN;

    const year = Number(rawDate.year);
    const month = Number(rawDate.month);
    const day = Number(rawDate.day);

    if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) return Number.NaN;
    if (month < 0 || month >= definition.months.length) return Number.NaN;

    const daysBeforeMonth = d3.sum(definition.months.slice(0, month), currentMonth => currentMonth.length);
    return (year - 1) * definition.yearLength + daysBeforeMonth + day;
}

function abbreviate(value: string, length: number): string {
    const trimmed = value.trim();
    if (trimmed.length <= length) return trimmed;
    return trimmed.slice(0, length);
}

function mod(value: number, divisor: number): number {
    return ((value % divisor) + divisor) % divisor;
}
