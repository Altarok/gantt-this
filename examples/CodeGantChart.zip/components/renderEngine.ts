import * as d3 from "d3";

import {
    getRelevantCalendarFiles,
    RenderItem,
    createRenderItemsFromFrontmatter
} from "./dataCollecting";
import {
    CalendarAxisDefinition,
    CalendarAxisSegment,
    choosePrimaryCalendarAxisLevel,
    getCalendarAxisSegments,
    getNextCalendarAxisLevel
} from "./calendarAxis";

// ----------------------------------------------------------
// Globale Darstellungs-Parameter
// ----------------------------------------------------------

// Diese Konstante legt die Höhe (Dicke) jedes Balkens fest.
// Sie steuert die visuelle Höhe der Rechtecke im Gantt-Chart.
const BAR_THICKNESS = 14;

// Diese Konstante legt den Radius jedes Punktes fest.
// Sie steuert die Größe der Kreise im Gantt-Chart.
const POINT_RADIUS = 2;

// Dieser Wert bestimmt den vertikalen Abstand zwischen zwei Lanes innerhalb derselben Gruppe.
// Dadurch entstehen Zwischenräume zwischen übereinander gestapelten Balken/Punkten.
const LANE_PADDING = 2;

// Dieser Wert bestimmt den vertikalen Abstand zwischen zwei Gruppen.
// So haben Gruppen optisch etwas Abstand voneinander.
const GROUP_PADDING = 4;

// NumericScaleConfig beschreibt eine numerische Skala (z.B. Ar/Km) für die X-Achse.
interface NumericScaleConfig {
    maxSpan: number;         // max. Spannweite, bis zu der diese Config gilt
    mode: "numeric";         // Moduskennzeichnung
    step: number;            // Tick-Abstand in Roh-Einheit
    unit: string;            // Einheitstext
    factor: number;          // Faktor, durch den der Rohwert geteilt wird
}

// PatternSegment beschreibt ein Segment im Pattern-Modus (z.B. A1, B2, C1).
interface PatternSegment {
    label: string;           // Label des Segments
    length: number;          // Länge des Segments in Roh-Einheiten
}

// PatternScaleConfig beschreibt eine Pattern-Skala (z.B. unterhalb einer bestimmten Spannweite).
interface PatternScaleConfig {
    maxSpan: number;         // max. Spannweite, bis zu der diese Config gilt
    mode: "pattern";         // Moduskennzeichnung
    patternLength: number;   // Gesamtlänge eines Pattern-Zyklus
    segments: PatternSegment[]; // Liste der Segmente im Zyklus
}

// XScaleConfig ist eine Union aus numerischer und Pattern-Konfiguration.
// Damit können wir je nach Modus unterschiedliche Logik anwenden.
type XScaleConfig = NumericScaleConfig | PatternScaleConfig;

export function renderGanttChartInternal(
    svgElement: SVGSVGElement,                     // SVG, in das wir zeichnen
    getRenderItems: () => RenderItem[],           // Funktion, die aktuelle RenderItems liefert (Filter berücksichtigt)
    sourcePath: string,                           // Pfad der aktuellen Note (für openLinkText / hover-link)
    extractLinkTarget: (noteName: string) => string, // Hilfsfunktion, die z.B. [[Titel]] -> "Titel" macht
    calendarAxisDefinition?: CalendarAxisDefinition | null
): void {
    const svg = d3.select<SVGSVGElement, unknown>(svgElement); // D3-Selection auf das SVG, parameter der Funktion

    // Breite aus dem width-Attribut des SVG auslesen
    const width: number = Number(svg.attr("width"));

    // Randbereiche definieren (Platz für Achsen & Titel)
    //const margin = { top: 30, right: 40, bottom: 80, left: 90 };
    const margin = { top: 0, right: 40, bottom: calendarAxisDefinition ? 60 : 40, left: 90 };

    // InnerWidth ist der Bereich, in dem der Gantt-Chart gezeichnet wird
    const innerWidth: number = width - margin.left - margin.right;

    // X-Skalen-Konfigurationen definieren (Pattern/Ar/Km)
    const xScaleConfigs: XScaleConfig[] = [
        {
            maxSpan: 100,
            mode: "pattern",
            patternLength: 100,
            segments: [
                { label: "A1", length: 21 },
                { label: "B2", length: 39 },
                { label: "C1", length: 40 }
            ]
        },
        {
            maxSpan: 1000,
            mode: "numeric",
            step: 100,
            unit: "Ar",
            factor: 100
        },
        {
            maxSpan: 10000,
            mode: "numeric",
            step: 1000,
            unit: "Km",
            factor: 1000
        },
        {
            maxSpan: Infinity,
            mode: "numeric",
            step: 5000,
            unit: "Km",
            factor: 1000
        }
    ];

    // Funktion, um passende X-Skalen-Konfiguration anhand der Spannweite zu wählen
    const getXScaleConfig = (span: number): { cfg: XScaleConfig; parentCfg: NumericScaleConfig | null } => {
        const idx = xScaleConfigs.findIndex(cfg => span <= cfg.maxSpan); // Index der passenden Konfiguration
        const cfg = idx === -1 ? xScaleConfigs[xScaleConfigs.length - 1] : xScaleConfigs[idx]; // fallback auf letzte bei -1
        let parentCfg: NumericScaleConfig | null = null;                 // übergeordnete Konfiguration initial null
        if (idx >= 0 && idx < xScaleConfigs.length - 1) {                // wenn noch eine gröbere Config existiert
            const candidate = xScaleConfigs[idx + 1];                     // nächste Config nehmen
            if (candidate.mode === "numeric") parentCfg = candidate;      // nur numeric als parent zulassen
        }
        return { cfg, parentCfg };                                        // Config + Parent zurückgeben
    };

    // Hilfsfunktion, um aus Pattern-Konfiguration eine Label-Funktion zu erzeugen
    const makePatternLabelFn = (patternLength: number, segments: PatternSegment[]) => {
        const total = d3.sum(segments, s => s.length);                    // Gesamtsegmentlänge
        if (total !== patternLength) console.warn("Pattern-Segmentlängen passen nicht zur patternLength");
        const bounds: { label: string; start: number; end: number }[] = []; // Grenzen für jedes Segment
        let cum = 0;
        for (const s of segments) {                                       // über alle Segmente iterieren
            bounds.push({ label: s.label, start: cum, end: cum + s.length }); // Segmentbereich speichern
            cum += s.length;                                              // cumulative Summe aktualisieren
        }
        return (value: number): string => {                               // zurückgegebene Funktion
            let local = value % patternLength;                            // Wert in Patternbereich falten
            if (local < 0) local += patternLength;
            for (const b of bounds) {                                     // passenden Segmentbereich finden
                if (local >= b.start && local < b.end) return b.label;
            }
            return "";                                                    // kein Segment gefunden -> leer
        };
    };

    // Aktuelle RenderItems (gefiltert) holen
    const data: RenderItem[] = getRenderItems();

    // SVG-Inhalt komplett leeren, um neu zu zeichnen
    svg.selectAll("*").remove();

    // Wenn keine Daten, Textmitteilung anzeigen und abbrechen
    if (!data || data.length === 0) {
        svg.append("text")
            .attr("x", width / 2)
            .attr("y", 50)
            .attr("text-anchor", "middle")
            .attr("fill", "#666")
            .text("Keine Daten für diese Ansicht");
        return;
    }

    // Interval-Hilfsfunktionen
    const getIntervalStart = (d: RenderItem): number => d.type === "bar" ? d.start : d.x;
    const getIntervalEnd = (d: RenderItem): number => d.type === "bar" ? d.end : d.x;

    // X-Bereich bestimmen
    const xMin = d3.min(data, getIntervalStart) ?? 0;
    const xMax = d3.max(data, getIntervalEnd) ?? 1;
    const xDomain: [number, number] = [xMin, xMax];

    // X-Skala linear anlegen
    const x = d3.scaleLinear()
        .domain(xDomain)
        .range([0, innerWidth])
        .clamp(true);

    const xSpan = xDomain[1] - xDomain[0]; // Spannweite für Auswahl der Konfiguration

    // Gruppen bestimmen und Items nach Gruppe gruppieren
    const groups = Array.from(new Set(data.map(d => d.group)));
    const dataByGroup = d3.group(data, d => d.group) as Map<string, RenderItem[]>;

    // Typ für Layout-Information je Gruppe
    type GroupLayout = {
        name: string;
        items: RenderItem[];
        laneCount: number;
        height: number;
        yOffset: number;
    };

    const groupLayouts: GroupLayout[] = []; // Liste aller Gruppen-Layouts
    let totalGroupsHeight = 0;              // Summe der Gruppenhöhen

    // Zuerst Lanes und Höhen berechnen
    for (const groupName of groups) {
        const itemsInGroup = dataByGroup.get(groupName) ?? [];
        // Items nach Start sortieren
        itemsInGroup.sort((a, b) => d3.ascending(getIntervalStart(a), getIntervalStart(b)));

        const laneEnds: number[] = [];      // laneEnds[i] = Endzeit der letzten Aktivität in Lane i
        itemsInGroup.forEach(item => {
            const start = getIntervalStart(item);
            const end = getIntervalEnd(item);
            let lane: number | null = null;
            // erste Lane suchen, in die das Item passt (start >= laneEnd)
            for (let i = 0; i < laneEnds.length; i++) {
                if (start >= laneEnds[i]) {
                    lane = i;
                    laneEnds[i] = end;
                    break;
                }
            }
            if (lane === null) {            // wenn keine frei, neue Lane anlegen
                lane = laneEnds.length;
                laneEnds.push(end);
            }
            item.lane = lane;              // Lane-Index am Item speichern
        });

        const laneCount = laneEnds.length || 1; // mindestens 1 Lane
        const groupHeight = laneCount * BAR_THICKNESS + Math.max(0, laneCount - 1) * LANE_PADDING; // Höhe berechnen

        groupLayouts.push({
            name: groupName,
            items: itemsInGroup,
            laneCount,
            height: groupHeight,
            yOffset: 0                  // wird im nächsten Schritt gesetzt
        });

        totalGroupsHeight += groupHeight; // Summe aller Gruppenhöhen erweitern
    }

    // Padding-Höhe zwischen Gruppen berechnen
    const totalPaddingHeight = Math.max(0, groups.length - 1) * GROUP_PADDING;
    totalGroupsHeight += totalPaddingHeight; // Gesamthöhe inkl. Padding

    const innerHeight = totalGroupsHeight;   // innerHeight = so hoch wie alle Gruppen zusammen

    // Höhe des gesamten SVG = innerHeight + Margins + Platz für Achsen/Bänder
    const svgHeight = innerHeight + margin.top + margin.bottom;
    svg.attr("height", String(svgHeight));

    // yOffset für Gruppen von unten nach oben berechnen:
    // wir starten bei innerHeight (X-Achse) und gehen nach oben
    let currentY = innerHeight;

    for (const gl of groupLayouts) {
        currentY -= gl.height;     // Platz für diese Gruppe
        gl.yOffset = currentY;     // yOffset setzen
        currentY -= GROUP_PADDING; // Abstand für nächste Gruppe
    }

    // Root-G (verschoben um Margins)
    const gRoot = svg.append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Clip-Path lediglich zur Sicherheit, dass nichts aus dem Plotbereich rausläuft
    svg.append("defs")
        .append("clipPath")
        .attr("id", "plot-clip")
        .append("rect")
        .attr("x", margin.left)
        .attr("y", margin.top)
        .attr("width", innerWidth)
        .attr("height", innerHeight);

    const plotArea = gRoot.append("g")
        .attr("class", "plot-area")
        .attr("clip-path", "url(#plot-clip)");

    // X-Achse unten (bei innerHeight)
    const xAxisGroup = gRoot.append("g")
        .attr("class", "axis x-axis")
        .attr("transform", `translate(0,${innerHeight})`);

    // Bänder für übergeordnete Skala (z. B. Km-Bereiche)
    const parentBandsGroup = gRoot.append("g")
        .attr("class", "x-axis-parent-bands")
        .attr("transform", `translate(0,${innerHeight + 24})`);

    // Y-Achse nur, wenn mehr als eine Gruppe
    const yAxisGroup = groups.length > 1
        ? gRoot.append("g").attr("class", "axis y-axis")
        : null;

    const gridGroup = gRoot.append("g")
        .attr("class", "grid");

    const renderCalendarAxis = (xScale: d3.ScaleLinear<number, number>) => {
        const domain = xScale.domain() as [number, number];
        const primaryLevel = choosePrimaryCalendarAxisLevel(calendarAxisDefinition!, xScale);
        const secondaryLevel = getNextCalendarAxisLevel(primaryLevel);
        const primarySegments = getCalendarAxisSegments(calendarAxisDefinition!, primaryLevel, domain);
        const secondarySegments = secondaryLevel
            ? getCalendarAxisSegments(calendarAxisDefinition!, secondaryLevel, domain)
            : [];

        xAxisGroup.selectAll("*").remove();
        parentBandsGroup.selectAll("*").remove();
        gridGroup.selectAll("*").remove();

        xAxisGroup.append("line")
            .attr("class", "calendar-axis-baseline")
            .attr("x1", 0)
            .attr("x2", innerWidth)
            .attr("y1", 0)
            .attr("y2", 0);

        const boundaryValues = Array.from(new Set(primarySegments.map(segment => segment.start)))
            .filter(value => value >= domain[0] && value <= domain[1])
            .sort((a, b) => a - b);

        const grid = d3.axisBottom(xScale)
            .tickValues(boundaryValues)
            .tickSize(-innerHeight)
            .tickFormat(() => "");

        gridGroup
            .attr("transform", `translate(0,${innerHeight})`)
            .call(grid);

        for (const segment of primarySegments) {
            const startX = xScale(segment.start);
            const endX = xScale(segment.end);
            const widthPx = endX - startX;
            if (widthPx <= 0) continue;

            xAxisGroup.append("line")
                .attr("class", "calendar-axis-tick")
                .attr("x1", startX)
                .attr("x2", startX)
                .attr("y1", 0)
                .attr("y2", 6);

            const label = chooseSegmentLabel(segment, widthPx);
            if (!label) continue;

            xAxisGroup.append("text")
                .attr("class", "calendar-axis-label primary")
                .attr("x", startX + widthPx / 2)
                .attr("y", 16)
                .text(label);
        }

        if (primarySegments.length > 0) {
            const lastSegment = primarySegments[primarySegments.length - 1];
            xAxisGroup.append("line")
                .attr("class", "calendar-axis-tick")
                .attr("x1", xScale(lastSegment.end))
                .attr("x2", xScale(lastSegment.end))
                .attr("y1", 0)
                .attr("y2", 6);
        }

        for (const segment of secondarySegments) {
            const startX = xScale(segment.start);
            const endX = xScale(segment.end);
            const widthPx = endX - startX;
            if (widthPx <= 0) continue;

            parentBandsGroup.append("rect")
                .attr("class", "calendar-parent-band")
                .attr("x", startX)
                .attr("y", 0)
                .attr("width", widthPx)
                .attr("height", 18);

            const label = chooseSegmentLabel(segment, widthPx);
            if (!label) continue;

            parentBandsGroup.append("text")
                .attr("class", "calendar-axis-label secondary")
                .attr("x", startX + widthPx / 2)
                .attr("y", 9)
                .text(label);
        }
    };

    // Funktion zum Aktualisieren der Achsen
    const updateAxes = (xScale: d3.ScaleLinear<number, number>) => {
        if (calendarAxisDefinition) {
            renderCalendarAxis(xScale);
        } else {
        const [d0, d1] = xScale.domain();
        const span = d1 - d0;
        const { cfg, parentCfg } = getXScaleConfig(span);

        if (cfg.mode === "numeric") {
            const niceStart = Math.ceil(d0 / cfg.step) * cfg.step;
            const niceEnd = Math.floor(d1 / cfg.step) * cfg.step;
            const ticks: number[] = d3.range(niceStart, niceEnd + cfg.step / 2, cfg.step);

            const xAxis = d3.axisBottom(xScale)
                .tickValues(ticks)
                .tickFormat((v: number | d3.NumberValue) => {
                    const val = Number(v);
                    return `${val / cfg.factor} ${cfg.unit}`;
                });

            xAxisGroup.call(xAxis);

            const grid = d3.axisBottom(xScale)
                .tickValues(ticks)
                .tickSize(-innerHeight)
                .tickFormat(() => "");

            gridGroup
                .attr("transform", `translate(0,${innerHeight})`)
                .call(grid);
        } else {
            const patternLength = cfg.patternLength;
            const labelFn = makePatternLabelFn(patternLength, cfg.segments);

            const ticks: number[] = [];
            let blockStart = Math.floor(d0 / patternLength) * patternLength;

            while (blockStart < d1 + patternLength) {
                let cum = 0;
                for (const seg of cfg.segments) {
                    const center = blockStart + cum + seg.length / 2;
                    if (center >= d0 && center <= d1) ticks.push(center);
                    cum += seg.length;
                }
                blockStart += patternLength;
            }

            const xAxis = d3.axisBottom(xScale)
                .tickValues(ticks)
                .tickFormat((v: number | d3.NumberValue) => {
                    const val = Number(v);
                    return labelFn(val);
                });

            xAxisGroup.call(xAxis);

            const grid = d3.axisBottom(xScale)
                .tickValues(ticks)
                .tickSize(-innerHeight)
                .tickFormat(() => "");

            gridGroup
                .attr("transform", `translate(0,${innerHeight})`)
                .call(grid);
        }

        parentBandsGroup.selectAll("*").remove();

        if (parentCfg) {
            const pStep = parentCfg.step;
            const pUnit = parentCfg.unit;

            const [d0p, d1p] = xScale.domain();
            const firstIndex = Math.floor(d0p / pStep);
            const lastIndex = Math.ceil(d1p / pStep);

            for (let i = firstIndex; i < lastIndex; i++) {
                const startVal = i * pStep;
                const endVal = (i + 1) * pStep;
                if (endVal <= d0p || startVal >= d1p) continue;

                const xStart = xScale(startVal);
                const xEnd = xScale(endVal);
                const bandWidth = xEnd - xStart;
                if (bandWidth <= 0) continue;

                parentBandsGroup.append("rect")
                    .attr("class", "parent-band")
                    .attr("x", xStart)
                    .attr("y", 0)
                    .attr("width", bandWidth)
                    .attr("height", 18);

                const labelIndex = i + 1;
                const labelText = `${pUnit}${labelIndex}`;

                parentBandsGroup.append("text")
                    .attr("class", "parent-band-label")
                    .attr("x", xStart + bandWidth / 2)
                    .attr("y", 9)
                    .text(labelText);
            }
        }

        }

        if (yAxisGroup) {
            const groupLayoutsForAxis = groupLayouts.map(gl => ({
                name: gl.name,
                pos: gl.yOffset + gl.height / 2
            }));

            const yScale = d3.scaleLinear()
                .domain([0, innerHeight])
                .range([0, innerHeight]);

            const yAxis = d3.axisLeft(yScale)
                .tickValues(groupLayoutsForAxis.map(t => t.pos))
                .tickFormat((v: number | d3.NumberValue) => {
                    const val = Number(v);
                    const match = groupLayoutsForAxis.find(t => Math.abs(t.pos - val) < 1e-6);
                    return match ? match.name : "";
                })
                .tickSize(0)
                .tickPadding(6);

            yAxisGroup.call(yAxis as any);
            yAxisGroup.selectAll("text").attr("class", "group-label");
        }
    };

    // Achsen initial zeichnen
    updateAxes(x);

    let hoverTimeout: number | null = null; // Timeout-ID für Hover-Vorschau

    // Gruppen-Gs auf Basis des Layouts erzeugen
    const groupG = plotArea.selectAll<SVGGElement, GroupLayout>(".group")
        .data(groupLayouts)
        .enter()
        .append("g")
        .attr("class", "group")
        .attr("transform", gl => `translate(0,${gl.yOffset})`);

    // Gruppen-Inhalte (Balken, Punkte, Labels) zeichnen
    groupG.each(function (gl: GroupLayout): void {
        const groupData = gl.items;
        const g = d3.select<SVGGElement, GroupLayout>(this);

        const laneCount = gl.laneCount;
        const [d0, d1] = x.domain();

        const laneCenterY = (laneIndex: number): number => {
            const totalLanesHeight = laneCount * BAR_THICKNESS + Math.max(0, laneCount - 1) * LANE_PADDING;
            const bottomY = totalLanesHeight - BAR_THICKNESS / 2;
            return bottomY - laneIndex * (BAR_THICKNESS + LANE_PADDING);
        };

        g.selectAll<SVGRectElement, RenderItem>("rect.bar")
            .data(groupData.filter(d => d.type === "bar"))
            .enter()
            .append("rect")
            .attr("class", "bar")
            .attr("y", d => {
                const lane = d.lane ?? 0;
                return laneCenterY(lane) - BAR_THICKNESS / 2;
            })
            .attr("x", d => {
                const s = Math.max(d.start, d0);
                const e = Math.min(d.end, d1);
                return x(s);
            })
            .attr("width", d => {
                const s = Math.max(d.start, d0);
                const e = Math.min(d.end, d1);
                return Math.max(0, x(e) - x(s));
            })
            .attr("height", BAR_THICKNESS)
            .attr("fill", d => d.color ?? "#4e79a7")
            .on("click", (_ev, d) => {
                const appAny = (window as any).app;
                const target = extractLinkTarget(d.noteName ?? "");
                appAny.workspace.openLinkText(target, sourcePath, "tab");
            });

        g.selectAll<SVGCircleElement, RenderItem>("circle.point")
            .data(groupData.filter(d => d.type === "point"))
            .enter()
            .append("circle")
            .attr("class", "point")
            .attr("cx", d => {
                const val = Math.max(d0, Math.min(d.x, d1));
                return x(val);
            })
            .attr("cy", d => {
                const lane = d.lane ?? 0;
                return laneCenterY(lane);
            })
            .attr("r", POINT_RADIUS)
            .attr("fill", d => d.color ?? "#e15759")
            .on("click", (_ev, d) => {
                const appAny = (window as any).app;
                const target = extractLinkTarget(d.noteName ?? "");
                appAny.workspace.openLinkText(target, sourcePath, "tab");
            });

        //let hoverPreview: any = null;
        //let hoverEvent: any = null;
        
        let hoverTimeout: number | null = null;
let currentHoverLink: string | null = null;

function openPreview(app: any, event: MouseEvent, link: string, sourcePath: string, svgElement: SVGSVGElement) {

    const hoverEvent = new MouseEvent("mousemove", {
        bubbles: true,
        clientX: event.clientX,
        clientY: event.clientY,
        ctrlKey: true
    });

    app.workspace.trigger("hover-link", {
        event: hoverEvent,
        source: "tzt-chart",
        hoverParent: svgElement,
        targetEl: svgElement,   // wichtig: stabile Position
        linktext: link,
        sourcePath: sourcePath
    });
}

function closePreview(app: any) {
    app.workspace.trigger("hover-link-cancel", {
        source: "tzt-chart"
    });
    currentHoverLink = null;
}
        
        
        g.selectAll<SVGTextElement, RenderItem>("text.bar-label") // collects all text elements which have a bar-label class
            .data(groupData)
            .enter()
            .append("text") //creates a text tag?
            .attr("class", "bar-label") // adds the bar-label class to the label elements
            .attr("y", d => {
                const lane = d.lane ?? 0;
                return laneCenterY(lane) + 4;
            })
            .attr("x", d => {
                const sx = d.type === "bar" ? d.start : d.x;
                const [d0L, d1L] = x.domain();
                const clamped = Math.max(d0L, Math.min(sx, d1L));
                return x(clamped) + 4;
            })
            .text(d => d.name)
            //.attr("pointer-events", "none") // Add this to prevent interaction issues <= only on zoom/pan out or in general? if set mouseenter is not triggered anymore
            .attr("pointer-events", "bounding-box") // //added but exact function?
            .attr("dominant-baseline", "middle") //added but exact function?
            .attr("font-size", "8px") //defines the text font size of the labels 
            .on("click", (_ev, d) => {
                const appAny = (window as any).app;
                const target = extractLinkTarget(d.noteName ?? "");
                appAny.workspace.openLinkText(target, sourcePath, "tab");
            })
            
            .on("mouseenter", function (event: MouseEvent, d: RenderItem) {

    const appAny = (window as any).app;
    const target = extractLinkTarget(d.noteName ?? "");

    if (hoverTimeout) clearTimeout(hoverTimeout);

    hoverTimeout = window.setTimeout(() => {

        if (currentHoverLink === target) return;

        closePreview(appAny);
        openPreview(appAny, event, target, sourcePath, svgElement);

        currentHoverLink = target;

    }, 250);
})

.on("mousemove", function(event: MouseEvent, d: RenderItem){

    if (!currentHoverLink) return;

    const appAny = (window as any).app;

    const hoverEvent = new MouseEvent("mousemove", {
        bubbles: true,
        clientX: event.clientX,
        clientY: event.clientY,
        ctrlKey: true
    });

    appAny.workspace.trigger("hover-link", {
        event: hoverEvent,
        source: "tzt-chart"
    });

})

.on("mouseleave", function(){

    const appAny = (window as any).app;

    if (hoverTimeout) {
        clearTimeout(hoverTimeout);
        hoverTimeout = null;
    }

    closePreview(appAny);

});
            
            /*
            .on("mouseenter", function (event: MouseEvent, d: RenderItem) {
                hoverPreview = null;
                if (hoverTimeout !== null) window.clearTimeout(hoverTimeout);
                hoverTimeout = window.setTimeout(() => {
                    const appAny = (window as any).app;
                    console.log("Note Name on Mouse enter: ",d.noteName)
                    const target = extractLinkTarget(d.noteName);

                    console.log("Resolved tartge Link from Note Name: ", target)
                    console.log("Source Path: ",sourcePath)
                    console.log("svgElement: ",svgElement)
                    console.log("Target Element",event.currentTarget as HTMLElement)

                    
                    //appAny.workspace.openHoverLinkText(
                        target,                     // linktext
                        sourcePath,                 // source path
                        {
                            event: event,
                            source: "tzt-chart",
                            hoverParent: svgElement,
                            targetEl: event.currentTarget as HTMLElement
                        }
                    );//

                   hoverEvent = new MouseEvent("mousemove", {
                        bubbles: true,
                        clientX: event.clientX,
                        clientY: event.clientY,
                        ctrlKey: true   // simuliert STRG gedrückt
                    });

                    appAny.workspace.trigger("hover-link-cancel", { source: "tzt-chart" });

                    hoverPreview=appAny.workspace.trigger("hover-link", {
                        event: hoverEvent,
                        source: "tzt-chart",
                        hoverParent: svgElement,
                        targetEl: event.currentTarget as HTMLElement,
                        target: target,
                        linktext: target, // actual link text/[[wikilink]] including subpath, linktext must be something Obsidian can resolve as an internal link from sourcePath
                        sourcePath: sourcePath // path of the file hosting the chart/hover link
                    });
                    
                        
                }, 1000);
            })
            .on("mouseleave", (event: MouseEvent) => {
                if (hoverTimeout !== null) {
                    window.clearTimeout(hoverTimeout);
                    hoverTimeout = null;
                    hoverPreview = null;
                    hoverEvent = null
                    //hoverPreview?.hide?.();
                }

                const appAny = (window as any).app;

                appAny.workspace.trigger("hover-link-cancel", {
                    event: event,
                    source: "tzt-chart",
                    targetEl: event.currentTarget
                });

            });*/
    });

    const targetMinSpanForPattern = 90;
    let maxZoom = xSpan / targetMinSpanForPattern;
    if (maxZoom < 1) maxZoom = 1;
    if (maxZoom > 200) maxZoom = 200;

    const zoom = d3.zoom<SVGSVGElement, unknown>()
        .scaleExtent([0.2, maxZoom])
        .translateExtent([[0, 0], [width, svgHeight]])
        .extent([[0, 0], [innerWidth, innerHeight]])
        .on("zoom", (event) => {
            const t = event.transform;
            const xz = t.rescaleX(x);
            const [d0, d1] = xz.domain();

            groupG.each(function (gl: GroupLayout): void {
                const groupData = gl.items;
                const g = d3.select<SVGGElement, GroupLayout>(this);

                const laneCount = gl.laneCount;
                const laneCenterY = (laneIndex: number): number => {
                    const totalLanesHeight = laneCount * BAR_THICKNESS + Math.max(0, laneCount - 1) * LANE_PADDING;
                    const bottomY = totalLanesHeight - BAR_THICKNESS / 2;
                    return bottomY - laneIndex * (BAR_THICKNESS + LANE_PADDING);
                };

                g.selectAll<SVGRectElement, RenderItem>("rect.bar")
                    .data(groupData.filter(d => d.type === "bar"))
                    .attr("x", d => {
                        const s = Math.max(d.start, d0);
                        const e = Math.min(d.end, d1);
                        return xz(s);
                    })
                    .attr("width", d => {
                        const s = Math.max(d.start, d0);
                        const e = Math.min(d.end, d1);
                        return Math.max(0, xz(e) - xz(s));
                    });

                g.selectAll<SVGCircleElement, RenderItem>("circle.point")
                    .data(groupData.filter(d => d.type === "point"))
                    .attr("cx", d => {
                        const val = Math.max(d0, Math.min(d.x, d1));
                        return xz(val);
                    });

                g.selectAll<SVGTextElement, RenderItem>("text.bar-label")
                    .data(groupData)
                    .attr("opacity", d => {
                        const sx = d.type === "bar" ? d.start : d.x;
                        // Hide label if it's outside the visible domain
                        if (sx < d0 || sx > d1) return 0;
                        return 1;
                    })
                    .attr("x", d => {
                        const sx = d.type === "bar" ? d.start : d.x;
                        const clamped = Math.max(d0, Math.min(sx, d1));
                        return xz(clamped) + 4;
                    });
                    
            });

            updateAxes(xz);
        });

    svg.call(zoom as any);

    svg.append("text")
        .attr("x", width / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .attr("font-size", "16px")
        .attr("font-weight", "bold")
        .text("Gantt-ähnliches Diagramm");
}

function chooseSegmentLabel(segment: CalendarAxisSegment, widthPx: number): string {
    if (widthPx >= 72) return segment.label;
    if (widthPx >= 36) return segment.shortLabel ?? segment.label;
    if (widthPx >= 18) return segment.tinyLabel ?? segment.shortLabel ?? segment.label;
    return "";
}
