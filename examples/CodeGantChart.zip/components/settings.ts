// settings.ts
import { App, PluginSettingTab, Setting, Notice } from "obsidian";
import { CalendarConfigModal } from "./calendarModal";

export interface FrontmatterMapping {
    calendarName: string;
    group: string;
    start: string;
    end: string;
    color: string;
}

export interface GanttPluginSettings {

    mapping: FrontmatterMapping;

    defaultCalendarName: string;

    defaultScalingMode: "none" | "date";

    calendars: CalendarSettings[];
}

export interface CalendarSettings {

    name: string;

    cycles: {
        id: string;
        category: string;
        level: number;
        repeating: boolean;
    }[];

    instances: {
        id: string;
        cycleId: string;
        name: string;
        index: number;
        baseLength: number;
    }[];
}

export const DEFAULT_SETTINGS: GanttPluginSettings = {
    mapping: {
        calendarName: "Gregorian",
        group: "fc-category",
        start: "fc-start",
        end: "fc-end",
        color: "fc-color"
    },
    defaultCalendarName: "Gregorian",
    defaultScalingMode: "none",
    calendars: []
};

export class GanttSettingTab extends PluginSettingTab {
    plugin: { settings: GanttPluginSettings; saveSettings: () => Promise<void> };
    // Track the active tab state
    private activeTab: "mapping" | "calendar" = "mapping";

    constructor(app: App, plugin: { settings: GanttPluginSettings; saveSettings: () => Promise<void> }) {
        super(app, plugin as any);
        this.plugin = plugin;
    }

    display(): void {
        const { containerEl } = this;
        containerEl.empty();

        containerEl.createEl("h2", { text: "Gantt Chart Einstellungen" });

        // --- Tab-Header ---
        const tabHeaderEl = containerEl.createEl("div", { cls: "tzt-settings-tab-header" });

        const mappingTabButton = tabHeaderEl.createEl("button", {
            cls: `tzt-tab-button ${this.activeTab === "mapping" ? "active" : ""}`,
            text: "Mapping"
        });

        const calendarTabButton = tabHeaderEl.createEl("button", {
            cls: `tzt-tab-button ${this.activeTab === "calendar" ? "active" : ""}`,
            text: "Kalenderdefinition"
        });

        // Tab-Switch Click Listeners
        mappingTabButton.addEventListener("click", () => {
            this.activeTab = "mapping";
            this.display(); // Re-render the UI
        });

        calendarTabButton.addEventListener("click", () => {
            this.activeTab = "calendar";
            this.display(); // Re-render the UI
        });

        // --- Tab-Content-Container ---
        const tabContentEl = containerEl.createEl("div", { cls: "tzt-settings-tab-content" });

        // Conditional rendering based on activeTab
        if (this.activeTab === "mapping") {
            this.renderMappingTab(tabContentEl);
        } else {
            this.renderCalendarTab(tabContentEl);
        }
    }

    //TAB 1
    private renderMappingTab(container: HTMLElement) {
        const sectionEl = container.createEl("div", { cls: "tzt-settings-section active" });

        new Setting(sectionEl)
            .setName("Frontmatter-Feld: Kalendername")
            .setDesc("Name des Frontmatter-Felds, das den Kalendernamen enthält.")
            .addText(text => text
                .setPlaceholder("z.B. kalender")
                .setValue(this.plugin.settings.mapping.calendarName)
                .onChange(async (value) => {
                    this.plugin.settings.mapping.calendarName = value.trim() || "kalender";
                    await this.plugin.saveSettings();
                    this.display();
                })
            );

        new Setting(sectionEl)
            .setName("Frontmatter-Feld: Gruppe")
            .setDesc("Name des Frontmatter-Felds, das die Gruppe (Y-Achse) enthält.")
            .addText(text => text
                .setPlaceholder("z.B. gruppe")
                .setValue(this.plugin.settings.mapping.group)
                .onChange(async (value) => {
                    this.plugin.settings.mapping.group = value.trim() || "gruppe";
                    await this.plugin.saveSettings();
                    this.display();
                })
            );

        new Setting(sectionEl)
            .setName("Frontmatter-Feld: Start")
            .setDesc("Name des Frontmatter-Felds für den Startwert (Pflichtfeld).")
            .addText(text => text
                .setPlaceholder("z.B. beginn")
                .setValue(this.plugin.settings.mapping.start)
                .onChange(async (value) => {
                    this.plugin.settings.mapping.start = value.trim() || "beginn";
                    await this.plugin.saveSettings();
                    this.display();
                })
            );

        new Setting(sectionEl)
            .setName("Frontmatter-Feld: Ende")
            .setDesc("Name des Frontmatter-Felds für den Endwert.")
            .addText(text => text
                .setPlaceholder("z.B. ende")
                .setValue(this.plugin.settings.mapping.end)
                .onChange(async (value) => {
                    this.plugin.settings.mapping.end = value.trim() || "ende";
                    await this.plugin.saveSettings();
                    this.display();
                })
            );

        new Setting(sectionEl)
            .setName("Standard-Skalierung")
            .setDesc("Wie Frontmatter-Werte umgewandelt werden sollen.")
            .addDropdown(drop => {
                drop
                    .addOption("none", "Keine (Werte sind Zahlen)")
                    .addOption("date", "Datum (per Date.getTime())")
                    .setValue(this.plugin.settings.defaultScalingMode)
                    .onChange(async (value: string) => {
                        this.plugin.settings.defaultScalingMode = value as "none" | "date";
                        await this.plugin.saveSettings();
                        this.display();
                    });
            });
    }

    // TAB 2
    private renderCalendarTab(container: HTMLElement) {
        const sectionEl = container.createEl("div", { cls: "tzt-settings-section active" });

        sectionEl.createEl("h3", { text: "Kalenderdefinition (Preview)" });
        sectionEl.createEl("p", {
            text: "Hier können in Zukunft spezifische Kalenderdefinitionen gepflegt werden."
        });

        new Setting(sectionEl)
            .setName("Kalender Definition")
            .setDesc("Öffnet in Zukunft eine Konfiguration.")
                   .addButton(button => button
    .setButtonText("Kalender Definition")
    .setCta()
    .onClick(() => {

        new CalendarConfigModal(
            this.app,
            this.plugin
        ).open()

    })

 
)
    }
}